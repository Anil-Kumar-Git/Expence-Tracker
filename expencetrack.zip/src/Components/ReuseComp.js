import React from 'react'

const UniqueId = () => {
  return Math.round(Math.random()*100);
}

export {UniqueId}
